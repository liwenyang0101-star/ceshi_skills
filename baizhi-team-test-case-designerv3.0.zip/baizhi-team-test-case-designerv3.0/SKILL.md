---
name: baizhi-team-test-case-designer
description: Design structured functional test cases for Baizhi Agent and similar products from requirements, development designs, UI behavior, parameter configuration, runtime or API behavior, and observed defects. Use when the user asks for functional cases or a Baizhi Excel workbook; analyzes requirement rules and confirmation points, maps coverage, and applies the explicitly provided creator email or leaves creator empty.
---

# Baizhi Team Test Case Designer

Design directly executable Chinese functional test cases for Baizhi Agent and similar products. Prefer observable product behavior over abstract testing advice.

## Optional Superpowers Extension

When `superpowers:using-superpowers` is available in the current environment, invoke it before analyzing inputs or designing test cases, then follow its skill-discovery workflow.

When it is unavailable, continue this skill's `Default Workflow` without asking the user to install anything, reporting an error, or blocking test-case output. Treat Superpowers as an optional enhancement, not a validation or delivery requirement.

## Workbook Output Rules

When the user asks for an Excel workbook, copy and populate:

```text
assets/functional-testcase-template.xlsx
```

Every generated workbook must contain exactly these three functional workflow sheets, in this order: `用例`, `需求确认点`, `需求梳理`. Do not add, remove, rename, or omit them. Populate confirmations and requirement analysis with real content; they are not passive placeholders.

- Put all generated functional cases in `用例`, preserving this exact column order:
  `projectId, demands, priority, case_name, nodeId, resource, steps_desc, steps_result, remark, creator`.
- `需求确认点` must use exactly: `序号`, `待确认问题`, `是否已解决`.
- `需求梳理` must use exactly: `需求编号`, `需求模块`, `需求内容拆解`, `规则梳理`, `适用对象`, `验收口径`, `测试级别`, `来源`, `覆盖用例模块`, `开发设计/技术影响`. Keep the optional technical column last so an absent development design does not create a blank column between business fields.
- Use `微软雅黑` for all three workflow sheets. Headers use 11-point bold text, centered horizontally and vertically, wrapped, with a 30-point row height and thin black borders. Use `#D9D9D9` with black text for `用例`, `#00B0F0` with black text for `需求确认点`, and `#4472C4` with white text for `需求梳理`.
- Format every populated body cell with 10-point regular black `微软雅黑`, top vertical alignment, wrapping, and thin `#B7B7B7` borders. Keep numeric and short identifier columns centered as defined by the template; use readable text alignment for descriptive columns.
- Apply body borders only to populated rows. Blank rows below generated content must remain unbordered and must not retain oversized template body formatting. Use readable wrapped row heights.
- Name the exported workbook after the requirement name. Replace only filesystem-unsafe characters while retaining the visible name as far as possible.
- Never create numbered blank confirmation rows.

### Field Rules

1. `projectId`, `demands`: write the exact supplied value; otherwise leave each cell empty.
2. `priority`: fill every case with only `P0`, `P1`, or `P2`; assess each case independently even if the user suggests a priority.
3. `case_name`: use a concise, user-visible behavior or verification target, not a step transcript.
4. `nodeId`: use a short, stable Chinese module name; put explanations in `remark`, not in `nodeId`.
5. `resource`: record meaningful preconditions; leave empty when none exists. Move prerequisite navigation and setup into `resource`, including login, opening the target page, preparing data, or pre-opening a dialog when those actions are not the behavior being verified.
6. `steps_desc` and `steps_result`: each line starts with `#`. A case has one scenario, one primary behavior target, and at most one primary state-changing or flow-advancing operation. If verification requires another click, selection, switch, input, save, submit, return, refresh, scroll, or other state-changing action, split it into another case and place the prior case's resulting state in that case's `resource`.
7. Multiple step/result pairs are allowed only when the first pair performs the single primary operation and every later step merely `查看、核对、记录、读取或等待` results already exposed by that same operation without changing state. Even then, `steps_desc` and `steps_result` must have the same number of `#` lines, and each step must map to exactly one result in the same ordinal position. If multiple observations are independently executable or meaningful, split them into separate cases.
8. Do not join independent expectations with “且”, “并且”, “同时”, “以及”, or similar wording. Do not use extra `#` lines to preserve a full navigation or operation transcript inside one case.
9. `remark`: may be empty; use it for parameter dependencies, linked data, risk notes, or key watchpoints.

### Atomic Case Examples

Allowed because one primary operation exposes one indivisible selection-state scenario without any second operation:

```text
resource: 已进入文件管理页，列表同时存在可传输和不可传输文件
steps_desc:
#点击全选
#查看已选数量
#查看不可传输文件的选择状态
steps_result:
#可传输文件全部被选中
#已选数量更新为可传输文件数量
#不可传输文件保持未选中
```

The three step/result pairs have equal counts and match by ordinal position. The later steps are passive observations only.

Must split because every line advances the workflow:

```text
#点击传输到 App
#选择蓝牙传输
#点击确认传输
```

Create separate cases for opening the transfer-method dialog, selecting Bluetooth, and confirming task creation. Carry each prior state into the next case's `resource`.

### Creator Rule

- If the user explicitly supplies an email, write that exact email as plain text in every generated case row.
- If no email is explicitly supplied, leave `creator` empty in every generated case row.
- Before writing cases, clear template creator values and email hyperlinks from the entire case write area.
- Never write an email-URI prefix into a creator cell.
- Do not infer a creator from any source. 不从模板、历史用例、当前系统账号、文件作者、示例或上下文推断邮箱。

## Input Analysis

Treat a requirement document as one supported input, not the only input. Analyze every available requirement text, development design, UI behavior, parameter configuration, runtime result, API behavior, and observed defect.

When inputs are combined:

1. Extract source-grounded facts, roles, scope, states, rules, exceptions, and sources.
2. Use a non-empty development design first to enrich requirement analysis with storage, caching, permission, compatibility, failure, and activation behavior; do not automatically turn every technical fact or enumerated interface into a case.
3. Never silently override an explicit product requirement with a development-design inference.
4. Put conflicts, ambiguity, and missing executable acceptance criteria into `需求确认点`.
5. Build `需求梳理` before cases, then map every requirement row to one or more actual generated `nodeId` values.
6. Perform a logical-condition cross-check (`逻辑条件交叉检查`) for every source rule that controls the same outcome: normalize each rule into a comparable decision rule, then check Boolean operator and precedence (`布尔运算符与优先级`), global-versus-tenant scope (`全局与租户范围`), role or permission scope (`角色或权限范围`), defaults, and activation timing (`默认值与激活时机`).
7. Compare each normalized rule's permitted users, tenants, and states (`允许集合`). If either rule broadens, narrows, bypasses, or contradicts the other, or their equivalence cannot be proved, create a confirmation point; treat OR/AND, scope, default, and timing differences as possible conflicts rather than supplements.

### Requirement-First Case Surface Selection

需求优先，开发设计作为辅助补充。开发设计最主要用于完善 `需求梳理`、解释业务规则和识别前端难以发现的风险，不用于机械展开接口、库表、字段或缓存实现用例。

Before adding a case derived from development design, select its verification surface in this order:

1. If the requirement explicitly defines an API contract, status code, response field, direct-access protection, or server-side security behavior, treat that interface behavior as a requirement-level acceptance surface.
2. Otherwise identify whether an existing requirement-derived frontend or normal business-flow case fully verifies the same observable business result.
3. 前端或正常业务流程能够完整验证同一业务结果时，不再生成重复或单独的接口用例；将接口、库表、缓存和数据流事实保留在 `需求梳理` 的 `开发设计/技术影响` 中。
4. 需求未涉及的开发设计部分，只有在能够转化为可执行功能用例时才生成用例：必须具有明确前置条件、单一主操作和可观察结果，并验证业务能力、安全防绕过、失败降级、配置生效或兼容行为，而不是验证实现存在本身。
5. A frontend-hidden entry does not prove server-side rejection. A direct API case remains necessary when it validates parameter bypass, unauthorized direct access, fallback behavior, or another result that the frontend cannot expose.
6. An endpoint list does not automatically require one positive regression case per endpoint. Create separate endpoint cases only when the frontend cannot prove the required server guard or when endpoints have different externally observable results, side effects, or risks.
7. After that necessity check, keep every surviving interface request atomic: one independently executed endpoint request per case. Do not merge several endpoints into one parameter group, matrix row, or batch step merely to reduce the case count.
8. Do not create cases solely to assert table names, columns, indexes, cache-key names, configuration-record shapes, internal method names, or internal response fields. Generate those cases only when the user explicitly asks for API/database implementation testing or that technical surface is the only executable acceptance surface.

## Requirement Confirmations

Use exactly the columns `序号`, `待确认问题`, `是否已解决`. Create sequential, nonblank rows whenever a question exists; a numbered row must never have an empty question or empty status.

Check for conflicts and for unclear UI state, text, navigation, role, scope, default, boundary, error code, timeout, retry, fallback, permission, activation timing, cache invalidation, migration, compatibility, API authentication, idempotency, failure behavior, and scenarios lacking executable acceptance.

- Resolved: `是：<已确认结论>`.
- Partially resolved: `部分：<已确认内容；剩余问题>`.
- Unresolved: `否（待产品/开发/测试确认）`.
- Never mark an inference as resolved. Record only an explicit source-backed conclusion as resolved.
- For a logical-condition cross-check, if `等价性无法证明`, create a nonblank unresolved confirmation. Preserve both source statements separately and traceably; `不得将争议条件合并为已解决验收口径`, silently select the development behavior, or create normal expected-behavior cases that assume the disputed interpretation is approved. If useful, create a discrepancy-exposure case whose expected result records or compares observed behavior against the pending product decision.
- If no point exists, write exactly this one row: `1 | 当前输入未识别到待确认问题 | 是（无需确认）`.

## Requirement Analysis Sheet

Use exactly the columns `需求编号`, `需求模块`, `需求内容拆解`, `规则梳理`, `适用对象`, `验收口径`, `测试级别`, `来源`, `覆盖用例模块`, `开发设计/技术影响`.

- Assign unique sequential IDs such as `REQ-01`.
- `需求内容拆解` 每行表达一个可独立理解、验证和追踪的需求点，使用简洁业务语言说明“要实现什么”。它可来自需求文档、用户故事、界面行为、参数配置、API 行为、运行结果、缺陷描述或其他有效输入；有可用输入时不得为空。若输入不足以形成可执行需求，记录已有事实，并将缺失信息写入 `需求确认点`。
- `规则梳理` 说明该需求点“在什么条件下如何成立”，包括状态、条件、权限、范围、边界、默认值、生效时机、异常和冲突规则，不与 `需求内容拆解` 重复。
- Record explicit applicable scope in `适用对象`.
- `开发设计/技术影响` 仅填写开发设计或其他明确技术材料提供的事实。在同一单元格内仅按实际存在的类别换行记录 `核心方案：…`、`接口：…`、`库表：…`、`缓存：…`、`配置：…` 或 `数据流：…`；未提供的类别不写。
- 没有任何明确技术信息时整个单元格保持空白。技术信息为空本身不生成确认点，不要求用户补充，也不阻塞用例设计或交付。
- 不得根据经验、产品表现、模板、历史用例或上下文推断接口名称、表名、字段、缓存键、配置项或实现方案。
- Define observable, executable acceptance in `验收口径`; mirror missing acceptance gaps to `需求确认点`.
- Set `测试级别` to `P0`, `P1`, `P2`, or an explicit combination when a rule genuinely spans levels.
- Cite a traceable input source in `来源`.
- Map `覆盖用例模块` to one or more actual generated `nodeId` values. Never use `需求梳理` itself as a `nodeId`.

## Case-Design Rules

Always cover, where applicable:

- normal and abnormal flows
- boundaries, empty values, and invalid values
- configuration changes before/after
- display, persistence, runtime effect, and relevant API/UI consistency

For parameter modules, cover default display, editability, save/apply behavior, subsequent-run effect, before/after comparison, and relevant trace, observability, or summary changes.

Common Baizhi modules include Playground, Manage, Evals, Traces, Marketplace, API Docs, Agent configuration, Agent prompt, Skills, MCP Servers, Temperature, Top P, and Max output.

When AI output comparison matters, use concrete copyable prompts rather than vague prompts, for example:

- `请给一个帮助团队管理会议纪要的AI产品起5个名字，并分别说明命名理由。`
- `请分别用正式、活泼、极简三种风格介绍AI Agent平台。`
- `请详细写一份Agent平台产品说明书的目录与每章摘要，至少包含8个章节。`

### Priority Policy

- `P0`: core run path, core parameter effect, save/apply success, critical API success/failure path, or key availability/correctness.
- `P1`: normal UI interaction, typical comparison, common display, or persistence validation.
- `P2`: regression, secondary display, or supplementary negative validation.

## Writing Style

- Output in Chinese unless the user requests another language.
- State exactly what is displayed, stored, rejected, triggered, or changed; do not write vague assertions such as “检查是否正常”.
- Keep each case focused on one scenario or verification point. Move setup-only actions to `resource`.
- Prefer directly importable workbook content when the user prepares an Excel or platform upload.

## Default Workflow

1. Identify every available input and source.
2. Extract and cross-check requirement rules.
3. Build `需求梳理` and assign sequential IDs.
4. Build `需求确认点`, including resolved supplements and unresolved gaps.
5. Build a requirement-first coverage map, then compare every technical candidate with existing frontend and business-flow coverage; remove duplicate interface or implementation-only cases.
6. Design the remaining executable cases and map requirement coverage to `nodeId`.
7. Copy the template, clear example content and hyperlinks from the write area, and populate all three sheets.
8. Apply the creator rule uniformly to every case row.
9. Validate content, coverage, formatting, and hyperlinks before export.
10. After export, reopen the workbook and repeat critical checks before delivery.

During case writing, assign priority, build concise Chinese `nodeId` values, move prerequisite navigation into `resource`, keep at most one state-changing or flow-advancing operation per case, preserve same-count and same-position step/result pairs, split independent validations into separate cases, and use `remark` for dependencies and risk notes.

## Mandatory Output Validation

Before presenting or exporting, validate all generated case rows and all three sheets. Revise and rerun validation if any check fails.

### Case Content

- Every `priority` is `P0`, `P1`, or `P2`; `projectId` and `demands` are empty unless explicitly supplied.
- Every creator cell is uniform: either all empty, or every row contains the exact explicitly supplied email.
- No creator cell contains an email-URI prefix and no creator cell retains a hyperlink.
- Every `nodeId` is a short Chinese module name; `steps_desc` and `steps_result` have the same number of `#` lines, and each pair maps one-to-one in the same ordinal position.
- Every case has at most one primary state-changing or flow-advancing operation. After the first primary operation, any remaining steps are limited to `查看、核对、记录、读取或等待` results already exposed by that operation. A second click, selection, switch, input, save, submit, return, refresh, scroll, or other state-changing action requires a separate case.
- No step line combines operations; no expected-result line combines independent checks. Prerequisite navigation belongs in `resource`, and multiple independently executable or meaningful checks require separate cases.
- Every development-design-derived case passes the requirement-first surface check: if a frontend or normal business-flow case already fully verifies the same business result, no duplicate interface case remains.
- Every technical-only case verifies an executable, externally observable behavior that is absent from requirement coverage. Pure implementation assertions remain in `开发设计/技术影响` unless the user explicitly requests API/database implementation testing.
- Repeated positive interface cases are not generated merely because development design lists multiple endpoints. Direct interface cases are retained only for requirement-level API contracts, frontend-invisible server guards, distinct side effects, or distinct risks.
- Every retained direct interface case contains exactly one endpoint request; endpoint lists are not collapsed into a parameterized or batch case.

### Confirmations and Requirement Analysis

- Confirmations contain at least one non-empty question and non-empty status, or exactly the explicit no-confirmation row `1 | 当前输入未识别到待确认问题 | 是（无需确认）`.
- No numbered blank confirmation row exists, and no inference is presented as resolved fact.
- Every same-outcome cross-source rule has completed the logical-condition cross-check (`逻辑条件交叉检查`): equivalent conditions are supported by the recorded comparison; any broadened, narrowed, bypassed, contradictory, or unproven condition has a nonblank `需求确认点` and is not used as resolved acceptance.
- `需求梳理` has the exact ten-column schema with `开发设计/技术影响` in the last column. Every row has a unique ID, nonblank requirement breakdown, rule, acceptance criterion, source, and covered case module. `开发设计/技术影响` may be blank only when no explicit technical material supports it.
- When explicit technical material exists, every technical statement is source-grounded; when it does not exist, every `开发设计/技术影响` cell is blank and its absence creates no confirmation or delivery blocker.
- Every requirement row maps to at least one actual generated `nodeId`; `需求梳理` is never used as that `nodeId`.

### Workbook and Export

- `用例` preserves its exact schema and readable formatting; generated borders occur only in populated case ranges.
- Reopen and verify all three header style contracts: 11-point bold `微软雅黑`, centered and wrapped, 30-point header row height, thin black borders, and the required header colors (`用例` `#D9D9D9` black text; `需求确认点` `#00B0F0` black text; `需求梳理` `#4472C4` white text).
- Reopen and verify the populated-body style contract on all three sheets: 10-point regular black `微软雅黑`, top alignment, wrapping, and thin `#B7B7B7` borders. Confirm the first blank row after generated content has no body borders.
- The workbook contains exactly `用例`, `需求确认点`, and `需求梳理`, and passes every content and coverage check after reopening.
- After export, reopen the workbook; do not deliver before the reopen validation passes.

## Do Not

- Do not leave priority empty or invent values for empty `projectId` or `demands`.
- Do not infer creator data, retain creator hyperlinks, or write an email-URI prefix in creator cells.
- Do not omit `需求梳理`, create numbered blank confirmation rows, or invent a resolved conclusion.
- Do not invent unsupported product behavior as fact.
- Do not infer technical implementation or treat absent development design as a confirmation point or delivery blocker.
- Do not expand development-design endpoint lists into duplicate positive interface cases when frontend or normal business-flow cases already verify the same result.
- Do not turn table, field, index, cache-key, configuration-record, internal-method, or internal-response implementation details into functional cases unless they meet the explicit technical-surface conditions above.
- `不得将争议条件合并为已解决验收口径` or silently choose one source; preserve both rules and raise a confirmation when their allowed scopes are not proven equivalent.
- `不得把争议行为写成正常预期`；only use a discrepancy-exposure case that records or compares observed behavior against the pending product decision when such coverage is useful.
- Do not deliver before reopening and passing the required validation.
- Do not output loose testing advice when the user asks for structured cases.
